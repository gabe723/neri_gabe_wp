# WordPress MySQL database migration
#
# Generated: Tuesday 11. April 2017 18:37 UTC
# Hostname: localhost
# Database: `gabe_wp`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

